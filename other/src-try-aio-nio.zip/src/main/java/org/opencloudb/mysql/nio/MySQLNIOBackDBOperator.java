package org.opencloudb.mysql.nio;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;
import org.opencloudb.backend.BackendConnection;
import org.opencloudb.backend.NIOBackDBOperator;
import org.opencloudb.backend.PhysicalDatasource;
import org.opencloudb.config.Capabilities;
import org.opencloudb.config.ErrorCode;
import org.opencloudb.config.Isolations;
import org.opencloudb.exception.UnknownTxIsolationException;
import org.opencloudb.mysql.CharsetUtil;
import org.opencloudb.mysql.SecurityUtil;
import org.opencloudb.mysql.nio.handler.ResponseHandler;
import org.opencloudb.net.AbstractConnection;
import org.opencloudb.net.NIOHandler;
import org.opencloudb.net.mysql.AuthPacket;
import org.opencloudb.net.mysql.CommandPacket;
import org.opencloudb.net.mysql.HandshakePacket;
import org.opencloudb.net.mysql.MySQLPacket;
import org.opencloudb.net.mysql.QuitPacket;
import org.opencloudb.route.RouteResultsetNode;
import org.opencloudb.server.ServerConnection;
import org.opencloudb.server.parser.ServerParse;
import org.opencloudb.util.TimeUtil;

public class MySQLNIOBackDBOperator extends NIOBackDBOperator {
	private static final Logger LOGGER = Logger
			.getLogger(MySQLNIOBackDBOperator.class);
	private static final long CLIENT_FLAGS = initClientFlags();
	private volatile boolean txSetCmdExecuted = false;
	private final AbstractConnection con;

	private static long initClientFlags() {
		int flag = 0;
		flag |= Capabilities.CLIENT_LONG_PASSWORD;
		flag |= Capabilities.CLIENT_FOUND_ROWS;
		flag |= Capabilities.CLIENT_LONG_FLAG;
		flag |= Capabilities.CLIENT_CONNECT_WITH_DB;
		// flag |= Capabilities.CLIENT_NO_SCHEMA;
		// flag |= Capabilities.CLIENT_COMPRESS;
		flag |= Capabilities.CLIENT_ODBC;
		// flag |= Capabilities.CLIENT_LOCAL_FILES;
		flag |= Capabilities.CLIENT_IGNORE_SPACE;
		flag |= Capabilities.CLIENT_PROTOCOL_41;
		flag |= Capabilities.CLIENT_INTERACTIVE;
		// flag |= Capabilities.CLIENT_SSL;
		flag |= Capabilities.CLIENT_IGNORE_SIGPIPE;
		flag |= Capabilities.CLIENT_TRANSACTIONS;
		// flag |= Capabilities.CLIENT_RESERVED;
		flag |= Capabilities.CLIENT_SECURE_CONNECTION;
		// client extension
		// flag |= Capabilities.CLIENT_MULTI_STATEMENTS;
		flag |= Capabilities.CLIENT_MULTI_RESULTS;
		return flag;
	}

	private static final CommandPacket _READ_UNCOMMITTED = new CommandPacket();
	private static final CommandPacket _READ_COMMITTED = new CommandPacket();
	private static final CommandPacket _REPEATED_READ = new CommandPacket();
	private static final CommandPacket _SERIALIZABLE = new CommandPacket();
	private static final CommandPacket _AUTOCOMMIT_ON = new CommandPacket();
	private static final CommandPacket _AUTOCOMMIT_OFF = new CommandPacket();
	private static final CommandPacket _COMMIT = new CommandPacket();
	private static final CommandPacket _ROLLBACK = new CommandPacket();
	static {
		_READ_UNCOMMITTED.packetId = 0;
		_READ_UNCOMMITTED.command = MySQLPacket.COM_QUERY;
		_READ_UNCOMMITTED.arg = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED"
				.getBytes();
		_READ_COMMITTED.packetId = 0;
		_READ_COMMITTED.command = MySQLPacket.COM_QUERY;
		_READ_COMMITTED.arg = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED"
				.getBytes();
		_REPEATED_READ.packetId = 0;
		_REPEATED_READ.command = MySQLPacket.COM_QUERY;
		_REPEATED_READ.arg = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ"
				.getBytes();
		_SERIALIZABLE.packetId = 0;
		_SERIALIZABLE.command = MySQLPacket.COM_QUERY;
		_SERIALIZABLE.arg = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE"
				.getBytes();
		_AUTOCOMMIT_ON.packetId = 0;
		_AUTOCOMMIT_ON.command = MySQLPacket.COM_QUERY;
		_AUTOCOMMIT_ON.arg = "SET autocommit=1".getBytes();
		_AUTOCOMMIT_OFF.packetId = 0;
		_AUTOCOMMIT_OFF.command = MySQLPacket.COM_QUERY;
		_AUTOCOMMIT_OFF.arg = "SET autocommit=0".getBytes();
		_COMMIT.packetId = 0;
		_COMMIT.command = MySQLPacket.COM_QUERY;
		_COMMIT.arg = "commit".getBytes();
		_ROLLBACK.packetId = 0;
		_ROLLBACK.command = MySQLPacket.COM_QUERY;
		_ROLLBACK.arg = "rollback".getBytes();
	}

	private HandshakePacket handshake;

	private long clientFlags;

	private volatile StatusSync statusSync;

	public MySQLNIOBackDBOperator(AbstractConnection con) {
		super();
		this.clientFlags = CLIENT_FLAGS;
		this.con = con;

	}

	public AbstractConnection getCon() {
		return con;
	}

	public void onConnectFailed(Throwable e) {
		this.error(ErrorCode.ERR_CONNECT_SOCKET, e);
	}

	public HandshakePacket getHandshake() {
		return handshake;
	}

	public void setHandshake(HandshakePacket handshake) {
		this.handshake = handshake;
	}

	public void authenticate() {
		AuthPacket packet = new AuthPacket();
		packet.packetId = 1;
		packet.clientFlags = clientFlags;

		packet.maxPacketSize = con.getMaxPacketSize();
		packet.charsetIndex = con.getCharsetIndex();
		packet.user = con.getUser();
		try {
			packet.password = passwd(con.getPassword(), handshake);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e.getMessage());
		}
		packet.database = con.getSchema();
		packet.write(con);
	}

	protected void sendQueryCmd(String query) {
		CommandPacket packet = new CommandPacket();
		packet.packetId = 0;
		packet.command = MySQLPacket.COM_QUERY;
		try {
			packet.arg = query.getBytes(con.getCharset());
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
		con.setLastWriteTime(TimeUtil.currentTimeMillis());
		packet.write(con);
	}

	private static class StatusSync {
		private final RouteResultsetNode rrn;
		private final MySQLNIOBackDBOperator conOperator;

		private CommandPacket schemaCmd;
		private CommandPacket charCmd;
		private CommandPacket isoCmd;
		private CommandPacket acCmd;
		private final String schema;
		private final int charIndex;
		private final int txIsolation;
		private final boolean autocommit;
		private volatile boolean executed;

		public StatusSync(MySQLNIOBackDBOperator conOperator,
				RouteResultsetNode rrn, int scCharIndex, int scTxtIsolation,
				boolean autocommit) {
			this.conOperator = conOperator;
			AbstractConnection con = conOperator.getCon();
			this.rrn = rrn;
			this.charIndex = scCharIndex;
			this.schema = con.getSchema();
			this.schemaCmd = con.isSchemaChanged() ? getChangeSchemaCommand(schema)
					: null;

			this.charCmd = con.getCharsetIndex() != charIndex ? getCharsetCommand(charIndex)
					: null;
			this.txIsolation = scTxtIsolation;

			this.isoCmd = con.getTxIsolation() != txIsolation ? getTxIsolationCommand(txIsolation)
					: null;
			if (!con.isModifiedSQLExecuted() || con.isFromSlaveDB()) {
				// never executed modify sql,so auto commit
				this.autocommit = true;
			} else {
				this.autocommit = autocommit;
			}
			if (this.autocommit) {
				this.acCmd = (con.isAutocommit() == true) ? null
						: _AUTOCOMMIT_ON;
			} else {// transaction
				if (!conOperator.txSetCmdExecuted) {
					this.acCmd = _AUTOCOMMIT_OFF;
				}
			}

			if (LOGGER.isDebugEnabled()) {
				StringBuilder inf = new StringBuilder();
				if (schemaCmd != null) {
					inf.append("   need syn schemaCmd " + schemaCmd + "\r\n");
				}
				if (charCmd != null) {
					inf.append("   need syn charCmd " + charCmd + "\r\n");
				}
				if (isoCmd != null) {
					inf.append("   need syn txIsolationCmd " + isoCmd + "\r\n");
				}
				if (acCmd != null) {
					inf.append("   need syn autcommitCmd " + acCmd + "\r\n");
				}
				if (inf.length() > 0) {
					LOGGER.debug(con + "\r\n" + inf);
				}
			}

		}

		private Runnable updater;

		public boolean isExecuted() {
			return executed;
		}

		public boolean isSync() {
			return schemaCmd == null && charCmd == null && isoCmd == null
					&& acCmd == null;
		}

		public void update() {
			Runnable updater = this.updater;
			if (updater != null) {
				updater.run();
			}
		}

		/**
		 * @return false if sync complete
		 */
		public boolean sync() {
			CommandPacket cmd;
			final AbstractConnection conn = conOperator.getCon();
			if (schemaCmd != null) {
				conn.setSchema("snyn...");
				updater = new Runnable() {
					@Override
					public void run() {
						conn.updateSchema(schema);
					}
				};
				cmd = schemaCmd;
				schemaCmd = null;
				cmd.write(conn);
				// System.out.println("syn schema "+conn+" schema "+schema);
				return true;
			}
			if (charCmd != null) {
				updater = new Runnable() {
					@Override
					public void run() {
						int ci = StatusSync.this.charIndex;
						conn.setCharsetIndex(ci);
					}
				};
				cmd = charCmd;
				charCmd = null;
				cmd.write(conn);
				// System.out.println("syn charCmd "+conn);
				return true;
			}
			if (isoCmd != null) {
				updater = new Runnable() {
					@Override
					public void run() {
						conn.setTxIsolation(StatusSync.this.txIsolation);
					}
				};
				cmd = isoCmd;
				isoCmd = null;
				cmd.write(conn);
				// System.out.println("syn iso "+conn);
				return true;
			}
			if (acCmd != null) {
				updater = new Runnable() {
					@Override
					public void run() {
						conn.setAutocommit(StatusSync.this.autocommit);
						if (StatusSync.this.autocommit == false) {
							conOperator.txSetCmdExecuted = true;
						}
					}
				};
				cmd = acCmd;
				acCmd = null;
				cmd.write(conn);
				// System.out.println("syn autocomit "+conn);
				return true;
			}
			return false;
		}

		public void execute() {
			executed = true;
			if (rrn.getStatement() != null) {
				conOperator.sendQueryCmd(rrn.getStatement());
			}

		}

		@Override
		public String toString() {
			return "StatusSync [schemaCmd=" + schemaCmd + ", charCmd="
					+ charCmd + ", isoCmd=" + isoCmd + ", acCmd=" + acCmd
					+ ", executed=" + executed + "]";
		}

		private static CommandPacket getTxIsolationCommand(int txIsolation) {
			switch (txIsolation) {
			case Isolations.READ_UNCOMMITTED:
				return _READ_UNCOMMITTED;
			case Isolations.READ_COMMITTED:
				return _READ_COMMITTED;
			case Isolations.REPEATED_READ:
				return _REPEATED_READ;
			case Isolations.SERIALIZABLE:
				return _SERIALIZABLE;
			default:
				throw new UnknownTxIsolationException("txIsolation:"
						+ txIsolation);
			}
		}

		private static CommandPacket getCharsetCommand(int ci) {
			String charset = CharsetUtil.getCharset(ci);
			StringBuilder s = new StringBuilder();
			s.append("SET names ").append(charset);
			CommandPacket cmd = new CommandPacket();
			cmd.packetId = 0;
			cmd.command = MySQLPacket.COM_QUERY;
			cmd.arg = s.toString().getBytes();
			return cmd;
		}

		private static CommandPacket getChangeSchemaCommand(String schema) {
			StringBuilder s = new StringBuilder();
			s.append(schema);
			CommandPacket cmd = new CommandPacket();
			cmd.packetId = 0;
			cmd.command = MySQLPacket.COM_INIT_DB;
			cmd.arg = s.toString().getBytes();
			return cmd;
		}
	}

	/**
	 * @return if synchronization finished and execute-sql has already been sent
	 *         before
	 */
	public boolean syncAndExcute() {
		StatusSync sync = statusSync;
		if (sync.isExecuted()) {
			return true;
		}
		if (sync.isSync()) {
			sync.update();
			sync.execute();
		} else {
			sync.update();
			sync.sync();
		}
		return false;
	}

	public void execute(RouteResultsetNode rrn, ServerConnection sc,
			boolean autocommit) throws UnsupportedEncodingException {
		if (!con.isModifiedSQLExecuted() && rrn.isModifySQL()) {
			con.setModifiedSQLExecuted(true);
		}
		StatusSync sync = new StatusSync(this, rrn, sc.getCharsetIndex(),
				sc.getTxIsolation(), autocommit);
		doExecute(sync);
	}

	/**
	 * by wuzh ,execute a query and ignore transaction settings for performance
	 * 
	 * @param sql
	 * @throws UnsupportedEncodingException
	 */
	public void query(String query) throws UnsupportedEncodingException {
		RouteResultsetNode rrn = new RouteResultsetNode("default",
				ServerParse.SELECT, query);

		StatusSync sync = new StatusSync(this, rrn, con.getCharsetIndex(),
				con.getTxIsolation(), true);
		doExecute(sync);
	}

	private void doExecute(StatusSync sync) {
		statusSync = sync;
		if (sync.isSync() || !sync.sync()) {
			sync.execute();
		}
	}

	public void quit() {
		if (!con.isClosed()) {
			if (con.isAuthenticated()) {
				// QS_TODO check
				con.write(QuitPacket.QUIT);
				con.write(con.allocate());
			} else {
				con.close("normal");
			}
		}
	}

	public void commit() {
		_COMMIT.write(this.con);
		txSetCmdExecuted = false;
	}

	public void rollback() {
		_ROLLBACK.write(this.con);
		txSetCmdExecuted = false;
	}

	public void release() {
		this.con.setAttachment(null);
		statusSync = null;
		con.setModifiedSQLExecuted(false);
		BackendConnection theCon = (BackendConnection) con;
		theCon.setResponseHandler(null);
		theCon.getPool().releaseChannel(theCon);
		txSetCmdExecuted = false;
	}

	@Override
	public void error(int errCode, Throwable t) {
		NIOHandler handler = con.getHandler();
		switch (errCode) {
		case ErrorCode.ERR_HANDLE_DATA:
			LOGGER.warn(" error code: " + errCode + " exception: " + t
					+ " con: " + this, t);
			break;
		case ErrorCode.ERR_PUT_WRITE_QUEUE:
			LOGGER.warn(" error code: " + errCode + " exception: " + t
					+ " con: " + this, t);
			break;
		case ErrorCode.ERR_CONNECT_SOCKET:
			if (handler == null) {
				LOGGER.warn(" error code: " + errCode + " exception: " + t
						+ " con: " + this);
				return;
			}
			if (handler instanceof MySQLConnectionHandler) {
				MySQLConnectionHandler theHandler = (MySQLConnectionHandler) handler;
				theHandler.connectionError(t);
			} else {
				((MySQLConnectionAuthenticator) handler)
.connectionError(
						(BackendConnection) con, t);
			}
			break;

		}
	}

	public ResponseHandler newResponseHandler(ResponseHandler queryHandler) {
		BackendConnection theCon = (BackendConnection) con;
		ResponseHandler handler = theCon.getResponseHandler();
		if (handler instanceof MySQLConnectionHandler) {
			((MySQLConnectionHandler) handler).setResponseHandler(queryHandler);
			return queryHandler;
		} else if (queryHandler != null) {
			LOGGER.warn("set not MySQLConnectionHandler "
					+ queryHandler.getClass().getCanonicalName());

		}
		return null;
	}

	/**
	 * 记录sql执行信息
	 */
	public void recordSql(String host, String schema, String stmt) {
		// final long now = TimeUtil.currentTimeMillis();
		// if (now > this.lastTime) {
		// // long time = now - this.lastTime;
		// // SQLRecorder sqlRecorder = this.pool.getSqlRecorder();
		// // if (sqlRecorder.check(time)) {
		// // SQLRecord recorder = new SQLRecord();
		// // recorder.host = host;
		// // recorder.schema = schema;
		// // recorder.statement = stmt;
		// // recorder.startTime = lastTime;
		// // recorder.executeTime = time;
		// // recorder.dataNode = pool.getName();
		// // recorder.dataNodeIndex = pool.getIndex();
		// // sqlRecorder.add(recorder);
		// // }
		// }
		// this.lastTime = now;
	}

	private static byte[] passwd(String pass, HandshakePacket hs)
			throws NoSuchAlgorithmException {
		if (pass == null || pass.length() == 0) {
			return null;
		}
		byte[] passwd = pass.getBytes();
		int sl1 = hs.seed.length;
		int sl2 = hs.restOfScrambleBuff.length;
		byte[] seed = new byte[sl1 + sl2];
		System.arraycopy(hs.seed, 0, seed, 0, sl1);
		System.arraycopy(hs.restOfScrambleBuff, 0, seed, sl1, sl2);
		return SecurityUtil.scramble411(passwd, seed);
	}

}
