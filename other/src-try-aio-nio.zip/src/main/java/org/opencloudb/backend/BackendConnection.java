package org.opencloudb.backend;

import org.opencloudb.mysql.nio.handler.ResponseHandler;
import org.opencloudb.net.ClosableConnection;

public interface BackendConnection extends ClosableConnection {

	public long getThreadId();

	public PhysicalDatasource getPool();

	public ResponseHandler getResponseHandler();

	public void setResponseHandler(ResponseHandler reponseHandle);

	// isClosedOrQuit

	public void release();

	public NIOBackDBOperator getDBOperator();

	public boolean isBorrowed();

	public boolean isModifiedSQLExecuted();

	public void setModifiedSQLExecuted(boolean modified);

	public boolean isFromSlaveDB();

	public void setBorrowed(boolean b);

	public void setThreadId(long threadId);

	public void setAuthenticated(boolean b);

	

}
