package org.opencloudb.backend;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.opencloudb.mysql.nio.handler.ResponseHandler;
import org.opencloudb.route.RouteResultsetNode;
import org.opencloudb.server.ServerConnection;

public abstract class NIOBackDBOperator {

	public abstract void quit();

	public abstract void commit();

	public abstract void query(String sql) throws UnsupportedEncodingException;

	public abstract void execute(RouteResultsetNode node,
			ServerConnection source, boolean autocommit) throws IOException;

	public abstract void error(int errCode, Throwable t);

	public abstract void release();

	public void recordSql(String host, String schema, String statement) {

	}

	// public boolean syncAndExcute()s;

	public abstract void rollback();

	public abstract ResponseHandler newResponseHandler(
			ResponseHandler reponseHandle);

}
