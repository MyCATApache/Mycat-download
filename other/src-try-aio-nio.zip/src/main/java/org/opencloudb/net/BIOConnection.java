package org.opencloudb.net;

public interface BIOConnection extends ClosableConnection{

}
