package org.opencloudb.net;

public interface SocketConnector {

}
