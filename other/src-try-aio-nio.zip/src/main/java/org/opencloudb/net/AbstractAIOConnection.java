package org.opencloudb.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.nio.channels.NetworkChannel;
import java.util.concurrent.locks.ReentrantLock;

import org.opencloudb.util.TimeUtil;

public abstract class AbstractAIOConnection extends AbstractConnection {

	protected final AsynchronousSocketChannel channel;
	private final ReentrantLock asynWriteCheckLock = new ReentrantLock();
	private AIOReadHandler aioReadHandler = new AIOReadHandler();
	private AIOWriteHandler aioWriteHandler = new AIOWriteHandler();

	public AbstractAIOConnection(AsynchronousSocketChannel channel)
			throws IOException {
		super();
		this.channel = channel;
		InetSocketAddress localAddr = (InetSocketAddress) channel
				.getLocalAddress();
		InetSocketAddress remoteAddr = (InetSocketAddress) channel
				.getRemoteAddress();
		this.host = remoteAddr.getHostString();
		this.port = localAddr.getPort();
		this.localPort = remoteAddr.getPort();
	}

	public void doNextWriteCheck() {
		if (writing == false) {
			try {
				asynWriteCheckLock.lock();
				if (writing) {
					return;
				}
				ByteBuffer buffer = writeQueue.poll();
				if (buffer != null) {
					writing = true;
					writeBuffer = buffer;
					asynWrite(buffer);
				}
			} finally {
				asynWriteCheckLock.unlock();
			}
		}
	}

	protected void onWriteFinished(int result) {
		netOutBytes += result;
		processor.addNetOutBytes(result);
		lastWriteTime = TimeUtil.currentTimeMillis();

		ByteBuffer theBuffer = writeBuffer;
		if (theBuffer.hasRemaining()) {
			theBuffer.compact();
			asynWrite(theBuffer);
			return;
		} else {// write finished
			this.recycle(theBuffer);
			writeBuffer = null;
			this.writing = false;
			this.doNextWriteCheck();

		}
	}

	private void asynWrite(ByteBuffer buffer) {
		if (buffer.position() == 0) {
			this.writeBuffer = null;
			this.recycle(buffer);
			this.close("quit sent");
			return;
		}
		buffer.flip();
		this.channel.write(buffer, this, aioWriteHandler);
	}

	public void doReadCheck() {

		ByteBuffer theBuffer = readBuffer;
		if (theBuffer == null) {
			theBuffer = processor.getBufferPool().allocate();
			this.readBuffer = theBuffer;
			channel.read(theBuffer, this, aioReadHandler);

		} else if (theBuffer.hasRemaining()) {
			channel.read(theBuffer, this, aioReadHandler);
		} else {
			throw new java.lang.IllegalArgumentException("full buffer to read ");
		}
	}

	public void onReadData(int got) throws IOException {
		if (isClosed.get()) {
			return;
		}
		ByteBuffer buffer = this.readBuffer;
		lastReadTime = TimeUtil.currentTimeMillis();
		if (got < 0) {
			if (!this.isClosed()) {
				this.close("socket closed");
				return;
			}
		} else if (got == 0) {
			return;
		}
		netInBytes += got;
		processor.addNetInBytes(got);

		// 澶勭悊鏁版嵁
		int offset = readBufferOffset, length = 0, position = buffer.position();
		for (;;) {
			length = getPacketLength(buffer, offset);
			if (length == -1) {
				if (!buffer.hasRemaining()) {
					buffer = checkReadBuffer(buffer, offset, position);
				}
				break;
			}
			if (position >= offset + length) {
				buffer.position(offset);
				byte[] data = new byte[length];
				buffer.get(data, 0, length);
				handle(data);

				offset += length;
				if (position == offset) {
					if (readBufferOffset != 0) {
						readBufferOffset = 0;
					}
					buffer.clear();
					break;
				} else {
					readBufferOffset = offset;
					buffer.position(position);
					continue;
				}
			} else {
				if (!buffer.hasRemaining()) {
					buffer = checkReadBuffer(buffer, offset, position);
				}
				break;
			}
		}
	}

	@Override
	public NetworkChannel getChannel() {
		return this.channel;
	}
}

class AIOWriteHandler implements
		CompletionHandler<Integer, AbstractAIOConnection> {

	@Override
	public void completed(final Integer result, final AbstractAIOConnection con) {
		try {
			if (result >= 0) {
				con.onWriteFinished(result);
			} else {
				con.close("write erro " + result);
			}
		} catch (Exception e) {
			AbstractConnection.LOGGER.warn("caught aio process err:" + e);
		}

	}

	@Override
	public void failed(Throwable exc, AbstractAIOConnection con) {
		con.close("write failed " + exc);
	}

}

class AIOReadHandler implements
		CompletionHandler<Integer, AbstractAIOConnection> {
	@Override
	public void completed(final Integer i, final AbstractAIOConnection con) {
		// con.getProcessor().getExecutor().execute(new Runnable() {
		// public void run() {
		if (i > 0) {
			try {
				con.onReadData(i);
				con.doReadCheck();
			} catch (IOException e) {
				con.close("handle err:" + e);
			}
		} else if (i == -1) {
			// System.out.println("read -1 xxxxxxxxx "+con);
			con.close("client closed");
		}
		// }
		// });
	}

	@Override
	public void failed(Throwable exc, AbstractAIOConnection con) {
		con.close(exc.toString());

	}
}