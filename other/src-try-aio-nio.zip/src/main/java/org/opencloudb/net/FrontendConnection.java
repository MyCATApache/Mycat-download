package org.opencloudb.net;

import org.opencloudb.net.handler.FrontendPrivileges;

public interface FrontendConnection extends NIOConnection {

	FrontendPrivileges getPrivileges();

	FrontConnectionLogic getConnectionLogic();

	void setAccepted(boolean b);

}
