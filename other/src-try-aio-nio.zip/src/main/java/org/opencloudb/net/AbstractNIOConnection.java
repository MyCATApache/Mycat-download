package org.opencloudb.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

import org.opencloudb.util.TimeUtil;

public abstract class AbstractNIOConnection extends AbstractConnection {
	private static final int OP_NOT_READ = ~SelectionKey.OP_READ;
	private static final int OP_NOT_WRITE = ~SelectionKey.OP_WRITE;
	protected SelectionKey processKey;
	protected final SocketChannel channel;
	protected boolean isFinishConnect;

	public AbstractNIOConnection(SocketChannel channel) {
		super();
		this.channel = channel;

	}

	public void doNextWriteCheck() throws IOException {
		boolean noMoreData = write0();
		if (noMoreData) {
			disableWrite();
		} else {
			if ((processKey.interestOps() & SelectionKey.OP_WRITE) == 0) {
				enableWrite(false);
			}
		}
	}

	private boolean write0() throws IOException {
		int written = 0;
		ByteBuffer buffer = writeBuffer;
		if (buffer != null) {
			while (buffer.hasRemaining()) {
				written = channel.write(buffer);
				if (written > 0) {
					netOutBytes += written;
					processor.addNetOutBytes(written);
					lastWriteTime = TimeUtil.currentTimeMillis();
				} else {
					break;
				}
			}

			if (buffer.hasRemaining()) {
				writeAttempts++;
				return false;
			} else {
				writeBuffer = null;
				recycle(buffer);
			}
		}
		while ((buffer = writeQueue.poll()) != null) {
			if (buffer.position() == 0) {
				recycle(buffer);
				this.close("quit send");
				return true;
			}
			buffer.flip();
			while (buffer.hasRemaining()) {
				written = channel.write(buffer);
				if (written > 0) {
					lastWriteTime = TimeUtil.currentTimeMillis();
					netOutBytes += written;
					processor.addNetOutBytes(written);
					lastWriteTime = TimeUtil.currentTimeMillis();
				} else {
					break;
				}
			}
			if (buffer.hasRemaining()) {
				this.writeBuffer = buffer;
				writeAttempts++;
				return false;
			} else {
				recycle(buffer);
			}
		}
		return true;
	}

	private void disableWrite() {
		try {
			SelectionKey key = this.processKey;
			key.interestOps(key.interestOps() & OP_NOT_WRITE);
		} catch (Exception e) {
			LOGGER.warn("can't disable write " + e);
		}

	}

	private void enableWrite(boolean wakeup) {
		boolean needWakeup = false;
		try {
			SelectionKey key = this.processKey;
			key.interestOps(key.interestOps() | SelectionKey.OP_WRITE);
			needWakeup = true;
		} catch (Exception e) {
			LOGGER.warn("can't enable write " + e);

		}
		if (needWakeup && wakeup) {
			processKey.selector().wakeup();
		}
	}

	public void disableRead() {

		SelectionKey key = this.processKey;
		key.interestOps(key.interestOps() & OP_NOT_READ);
	}

	public void enableRead() {

		boolean needWakeup = false;
		try {
			SelectionKey key = this.processKey;
			key.interestOps(key.interestOps() | SelectionKey.OP_READ);
			needWakeup = true;
		} catch (Exception e) {
			LOGGER.warn("enable read fail " + e);
		}
		if (needWakeup) {
			processKey.selector().wakeup();
		}
	}

	public void connect(Selector selector) throws IOException {
		channel.register(selector, SelectionKey.OP_CONNECT, this);
		channel.connect(new InetSocketAddress(host, port));
	}

	public boolean finishConnect() throws IOException {
		if (channel.isConnectionPending()) {
			channel.finishConnect();
			localPort = channel.socket().getLocalPort();
			isFinishConnect = true;
			return true;
		} else {
			return false;
		}
	}

	private void clearSelectionKey() {
		try {
			SelectionKey key = this.processKey;
			if (key != null && key.isValid()) {
				key.attach(null);
				key.cancel();
			}
		} catch (Exception e) {
			LOGGER.warn("clear selector keys err:" + e);
		}
	}

	protected void closeSocket() {
		clearSelectionKey();
		super.closeSocket();
	}

	public void register(Selector selector) throws IOException {
		try {
			processKey = channel.register(selector, SelectionKey.OP_READ, this);
			// isRegistered = true;
		} finally {
			if (isClosed.get()) {
				clearSelectionKey();
			}
		}
	}
}
