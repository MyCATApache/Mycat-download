/*
 * Copyright (c) 2013, OpenCloudDB/MyCAT and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software;Designed and Developed mainly by many Chinese 
 * opensource volunteers. you can redistribute it and/or modify it under the 
 * terms of the GNU General Public License version 2 only, as published by the
 * Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * Any questions about this component can be directed to it's project Web address 
 * https://code.google.com/p/opencloudb/.
 *
 */
package org.opencloudb.net;

import java.nio.ByteBuffer;
import java.util.Collection;

/**
 * @author mycat
 */
public interface NIOConnection extends ClosableConnection {

	

	public int getTxIsolation();

	public void setTxIsolation(int newIsolation);

	public String getPassword();

	public void setPassword(String password);

	public String getUser();

	void setUser(String user);

	void setPacketHeaderSize(int packetHeaderSize);

	void setMaxPacketSize(int maxPacketSize);

	int getPacketHeaderSize();

	void setProcessor(NetDataProcessor processor);

	public boolean isAutocommit();

	public void setAutocommit(boolean autoCommit);

	public Object getAttachment();

	/**
	 * 处理数据
	 */
	void handle(byte[] data);

	public NIOHandler getHandler();

	void setHandler(NIOHandler cmdHandler);

	/**
	 * 坚持传入的写Buffer是否够大，不够就先写入，并创建和返回新的Buffer
	 * 
	 * @param buffer
	 * @param capacity
	 *            目标容量
	 * @param writeSocketIfFull
	 *            是否写入Socket（一般应该是要写入）
	 * @return
	 */
	public ByteBuffer checkWriteBuffer(ByteBuffer buffer, int capacity,
			boolean writeSocketIfFull);

	/**
	 * 写出一块缓存数据
	 */
	void write(ByteBuffer buffer);

	void write(byte[] bytes);

	/**
	 * 检查或开启读事件
	 */
	public void doReadCheck();

	/**
	 * 数据写入Buffer，若满了则写入队列并返回新Buffer
	 * 
	 * @param src
	 * @param buffer
	 * @return
	 */
	public ByteBuffer writeToBuffer(byte[] src, ByteBuffer buffer);

	public Collection<ByteBuffer> getWriteQueue();

	/**
	 * 分配Buffer
	 * 
	 * @return
	 */
	public ByteBuffer allocate();

	/**
	 * 回收Buffer
	 * 
	 * @param buffer
	 */
	public void recycle(ByteBuffer buffer);

	/**
	 * 发生错误
	 */
	void error(int errCode, Throwable t);

	public NetDataProcessor getProcessor();

	void cleanup();
}