/*
 * Copyright (c) 2013, OpenCloudDB/MyCAT and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software;Designed and Developed mainly by many Chinese 
 * opensource volunteers. you can redistribute it and/or modify it under the 
 * terms of the GNU General Public License version 2 only, as published by the
 * Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 * 
 * Any questions about this component can be directed to it's project Web address 
 * https://code.google.com/p/opencloudb/.
 *
 */
package org.opencloudb.net;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.AsynchronousSocketChannel;

import org.opencloudb.backend.BackendConnection;
import org.opencloudb.backend.NIOBackDBOperator;
import org.opencloudb.backend.PhysicalDatasource;
import org.opencloudb.mysql.nio.handler.ResponseHandler;

/**
 * @author mycat
 */
public class BackendAIOConnection extends AbstractAIOConnection implements
		BackendConnection {

	/**
	 * used for detail sql based operaction logic
	 * 
	 * @return
	 */
	private NIOBackDBOperator conOperator;
	private final boolean fromSlaveDB;
	protected long threadId;
	protected final PhysicalDatasource pool;
	protected volatile boolean borrowed;
	protected volatile boolean modifiedSQLExecuted;
	protected volatile ResponseHandler responseHandler;
	protected boolean isFinishConnect;

	public BackendAIOConnection(PhysicalDatasource pool,
			AsynchronousSocketChannel channel, boolean fromSlaveDB)
			throws IOException {
		super(channel);
		this.fromSlaveDB = fromSlaveDB;
		this.pool = pool;

	}

	public boolean isFromSlaveDB() {
		return fromSlaveDB;
	}

	public long getThreadId() {
		return threadId;
	}

	public void setThreadId(long threadId) {
		this.threadId = threadId;
	}

	public boolean isBorrowed() {
		return borrowed;
	}

	public void setBorrowed(boolean borrowed) {
		this.borrowed = borrowed;
	}

	public boolean isModifiedSQLExecuted() {
		return modifiedSQLExecuted;
	}

	public void setModifiedSQLExecuted(boolean modifiedSQLExecuted) {
		this.modifiedSQLExecuted = modifiedSQLExecuted;
	}

	public ResponseHandler getResponseHandler() {
		return responseHandler;
	}

	public PhysicalDatasource getPool() {
		return pool;
	}

	public void register() {
		this.doReadCheck();
	}

	public boolean finishConnect() throws IOException {
		localPort = ((InetSocketAddress) channel.getLocalAddress()).getPort();
		isFinishConnect = true;
		return true;
	}

	public void setProcessor(NetDataProcessor processor) {
		super.setProcessor(processor);
		processor.addBackend(this);
	}

	public void onConnectFailed(Throwable exc) {
		LOGGER.info("todo ,conenction faild " + this);
	}

	@Override
	public void error(int errCode, Throwable t) {
		conOperator.error(errCode, t);

	}

	@Override
	public void release() {
		conOperator.release();

	}

	@Override
	public void setResponseHandler(ResponseHandler reponseHandle) {
		ResponseHandler newHandler = conOperator
				.newResponseHandler(reponseHandle);
		if (newHandler != null) {
			this.responseHandler = newHandler;
		}

	}

	@Override
	public NIOBackDBOperator getDBOperator() {
		return conOperator;
	}
}