package org.opencloudb.net;

import java.io.IOException;

import org.opencloudb.buffer.BufferPool;
import org.opencloudb.util.NameableExecutor;

public class NIONetDataProcessor extends NetDataProcessor {

	private final NIOReactor reactor;

	public NIONetDataProcessor(String name, BufferPool bufferPool,
			NameableExecutor executor) throws IOException {
		super(name, bufferPool, executor);
		this.reactor = new NIOReactor(name);
	}

	public void postRegister(AbstractNIOConnection c) {
		reactor.postRegister(c);

	}

}
