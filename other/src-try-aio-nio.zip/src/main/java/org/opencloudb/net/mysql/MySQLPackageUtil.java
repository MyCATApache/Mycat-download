package org.opencloudb.net.mysql;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.opencloudb.net.FrontendConnection;

public class MySQLPackageUtil {
	public static void writeErrMessage(int errno, String msg,
			FrontendConnection frontCon) throws IOException {
		writeErrMessage((byte) 1, errno, msg, frontCon);
	}

	public static void writeErrMessage(byte id, int errno, String msg,
			FrontendConnection frontCon) throws IOException {
		ErrorPacket err = new ErrorPacket();
		err.packetId = id;
		err.errno = errno;
		err.message = encodeString(msg, frontCon.getCharset());
		err.write(frontCon);
	}

	private final static byte[] encodeString(String src, String charset) {
		if (src == null) {
			return null;
		}
		if (charset == null) {
			return src.getBytes();
		}
		try {
			return src.getBytes(charset);
		} catch (UnsupportedEncodingException e) {
			return src.getBytes();
		}
	}
}
