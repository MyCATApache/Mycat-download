package org.opencloudb.net;

public interface SocketAcceptor {

	void start();

	String getName();

	int getPort();

}
