package org.opencloudb.net;

import java.io.EOFException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.opencloudb.config.Capabilities;
import org.opencloudb.config.ErrorCode;
import org.opencloudb.config.Versions;
import org.opencloudb.mysql.MySQLMessage;
import org.opencloudb.net.handler.FrontendPrepareHandler;
import org.opencloudb.net.handler.FrontendPrivileges;
import org.opencloudb.net.handler.FrontendQueryHandler;
import org.opencloudb.net.mysql.HandshakePacket;
import org.opencloudb.net.mysql.MySQLPackageUtil;
import org.opencloudb.net.mysql.MySQLPacket;
import org.opencloudb.net.mysql.OkPacket;
import org.opencloudb.util.RandomUtil;

public class FrontConnectionLogic {
	private static final Logger LOGGER = Logger
			.getLogger(FrontConnectionLogic.class);
	private FrontendConnection frontCon;
	protected byte[] seed;
	protected FrontendPrivileges privileges;
	protected FrontendQueryHandler queryHandler;
	protected FrontendPrepareHandler prepareHandler;
	protected boolean isAuthenticated;

	public FrontendConnection getFrontCon() {
		return frontCon;
	}

	public void setFrontCon(FrontendConnection frontCon) {
		this.frontCon = frontCon;
	}

	public void initDB(byte[] data) throws IOException {
		MySQLMessage mm = new MySQLMessage(data);
		mm.position(5);
		String db = mm.readString();
		// 检查schema的有效性
		if (db == null || !privileges.schemaExists(db)) {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_BAD_DB_ERROR,
					"Unknown database '" + db + "'", frontCon);
			return;
		}
		String user = frontCon.getUser();
		String host = frontCon.getHost();
		if (!privileges.userExists(user, host)) {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_ACCESS_DENIED_ERROR,
					"Access denied for user '" + user + "'", frontCon);
			return;
		}
		Set<String> schemas = privileges.getUserSchemas(user);
		if (schemas == null || schemas.size() == 0 || schemas.contains(db)) {
			frontCon.setSchema(db);
			frontCon.write(OkPacket.OK);
		} else {
			String s = "Access denied for user '" + user + "' to database '"
					+ db + "'";
			MySQLPackageUtil.writeErrMessage(
					ErrorCode.ER_DBACCESS_DENIED_ERROR, s, frontCon);
		}
	}

	public void query(byte[] data) throws IOException {
		if (queryHandler != null) {
			// 取得语句
			MySQLMessage mm = new MySQLMessage(data);
			mm.position(5);
			String sql = null;
			String charset = frontCon.getCharset();
			try {
				sql = mm.readString(charset);
			} catch (UnsupportedEncodingException e) {
				MySQLPackageUtil.writeErrMessage(
						ErrorCode.ER_UNKNOWN_CHARACTER_SET, "Unknown charset '"
								+ charset + "'", frontCon);
				return;
			}
			if (sql == null || sql.length() == 0) {
				MySQLPackageUtil
						.writeErrMessage(ErrorCode.ER_NOT_ALLOWED_COMMAND,
								"Empty SQL", frontCon);
				return;
			}
			// remove last ';'
			if (sql.endsWith(";")) {
				sql = sql.substring(0, sql.length() - 1);
			}

			// 执行查询
			queryHandler.setReadOnly(privileges.isReadOnly(frontCon.getUser()));
			queryHandler.query(sql);
		} else {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
					"Query unsupported!", frontCon);
		}
	}

	public void stmtPrepare(byte[] data) throws IOException {
		if (prepareHandler != null) {
			// 取得语句
			MySQLMessage mm = new MySQLMessage(data);
			mm.position(5);
			String sql = null;
			String charset = frontCon.getCharset();
			try {
				sql = mm.readString(charset);
			} catch (UnsupportedEncodingException e) {
				MySQLPackageUtil.writeErrMessage(
						ErrorCode.ER_UNKNOWN_CHARACTER_SET, "Unknown charset '"
								+ charset + "'", frontCon);
				return;
			}
			if (sql == null || sql.length() == 0) {
				MySQLPackageUtil
						.writeErrMessage(ErrorCode.ER_NOT_ALLOWED_COMMAND,
								"Empty SQL", frontCon);
				return;
			}

			// 执行预处理
			prepareHandler.prepare(sql);
		} else {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
					"Prepare unsupported!", frontCon);
		}
	}

	public void stmtExecute(byte[] data) throws IOException {
		if (prepareHandler != null) {
			prepareHandler.execute(data);
		} else {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
					"Prepare unsupported!", frontCon);
		}
	}

	public void stmtClose(byte[] data) throws IOException {
		if (prepareHandler != null) {
			prepareHandler.close();
		} else {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
					"Prepare unsupported!", frontCon);
		}
	}

	public void ping() throws IOException {
		frontCon.write(OkPacket.OK);
	}

	public void heartbeat(byte[] data) throws IOException {
		frontCon.write(OkPacket.OK);
	}

	public void kill(byte[] data) throws IOException {
		MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
				"Unknown command", frontCon);
	}

	public void unknown(byte[] data) throws IOException {
		MySQLPackageUtil.writeErrMessage(ErrorCode.ER_UNKNOWN_COM_ERROR,
				"Unknown command", frontCon);
	}

	public void setQueryHandler(FrontendQueryHandler queryHandler) {
		this.queryHandler = queryHandler;
	}

	public void setPrepareHandler(FrontendPrepareHandler prepareHandler) {
		this.prepareHandler = prepareHandler;
	}

	public void setAuthenticated(boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}

	public FrontendPrivileges getPrivileges() {
		return privileges;
	}

	public void setPrivileges(FrontendPrivileges privileges) {
		this.privileges = privileges;
	}

	protected int getServerCapabilities() {
		int flag = 0;
		flag |= Capabilities.CLIENT_LONG_PASSWORD;
		flag |= Capabilities.CLIENT_FOUND_ROWS;
		flag |= Capabilities.CLIENT_LONG_FLAG;
		flag |= Capabilities.CLIENT_CONNECT_WITH_DB;
		// flag |= Capabilities.CLIENT_NO_SCHEMA;
		// flag |= Capabilities.CLIENT_COMPRESS;
		flag |= Capabilities.CLIENT_ODBC;
		// flag |= Capabilities.CLIENT_LOCAL_FILES;
		flag |= Capabilities.CLIENT_IGNORE_SPACE;
		flag |= Capabilities.CLIENT_PROTOCOL_41;
		flag |= Capabilities.CLIENT_INTERACTIVE;
		// flag |= Capabilities.CLIENT_SSL;
		flag |= Capabilities.CLIENT_IGNORE_SIGPIPE;
		flag |= Capabilities.CLIENT_TRANSACTIONS;
		// flag |= ServerDefs.CLIENT_RESERVED;
		flag |= Capabilities.CLIENT_SECURE_CONNECTION;
		return flag;
	}

	public void register() throws IOException {
		if (!frontCon.isClosed()) {

			// 生成认证数据
			byte[] rand1 = RandomUtil.randomBytes(8);
			byte[] rand2 = RandomUtil.randomBytes(12);

			// 保存认证数据
			byte[] seed = new byte[rand1.length + rand2.length];
			System.arraycopy(rand1, 0, seed, 0, rand1.length);
			System.arraycopy(rand2, 0, seed, rand1.length, rand2.length);
			this.seed = seed;

			// 发送握手数据包
			HandshakePacket hs = new HandshakePacket();
			hs.packetId = 0;
			hs.protocolVersion = Versions.PROTOCOL_VERSION;
			hs.serverVersion = Versions.SERVER_VERSION;
			hs.threadId = frontCon.getId();
			hs.seed = rand1;
			hs.serverCapabilities = getServerCapabilities();
			hs.serverCharsetIndex = (byte) (frontCon.getCharsetIndex() & 0xff);
			hs.serverStatus = 2;
			hs.restOfScrambleBuff = rand2;
			hs.write(frontCon);

			// asynread response
			frontCon.doReadCheck();
		}
	}

	protected boolean isConnectionReset(Throwable t) {
		if (t instanceof IOException) {
			String msg = t.getMessage();
			return (msg != null && msg.contains("Connection reset by peer"));
		}
		return false;
	}

	public void error(int errCode, Throwable t) {
		// 根据异常类型和信息，选择日志输出级别。
		if (t instanceof EOFException) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(toString(), t);
			}
		} else if (isConnectionReset(t)) {
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info(toString(), t);
			}
		} else {
			LOGGER.warn(toString(), t);
		}
		String msg = t.getMessage();
		try {
			MySQLPackageUtil.writeErrMessage(ErrorCode.ER_YES, msg == null ? t
					.getClass().getSimpleName() : msg, this.frontCon);
		} catch (IOException e) {
			LOGGER.warn(frontCon + " caught err " + e);
			frontCon.close("err:" + e);
		}

	}

	public void handle(byte[] data) {
		if (data[4] == MySQLPacket.COM_QUIT) {
			frontCon.getProcessor().getCommands().doQuit();
			frontCon.close("quit cmd");
			return;

		}
		frontCon.getHandler().handle(data);

	}

}
