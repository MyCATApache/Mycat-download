package org.opencloudb.jdbc;

import org.opencloudb.heartbeat.DBHeartbeat;

public class JDBCHeatbeat extends DBHeartbeat{

	@Override
	public void start() {
		
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getLastActiveTime() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getTimeout() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void heartbeat() {
		// TODO Auto-generated method stub
		
	}

}
